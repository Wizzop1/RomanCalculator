package com.example.digitconverter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;

public class HelloController {

    @FXML
    private Button btnCalculate;

    @FXML
    private Button btnClear;

    @FXML
    private Label calcScreen;

    @FXML
    private MenuButton converButton;

    @FXML
    private Button fiftyButton;

    @FXML
    private Button fiveButton;

    @FXML
    private Button hundredButton;

    @FXML
    private MenuItem menuArabic;

    @FXML
    private MenuItem menuRoman;

    @FXML
    private Button oneButton;

    @FXML
    private Button tenButton;

    @FXML
    void onCalculate(ActionEvent event) {

    }

    @FXML
    void onClear(ActionEvent event) {
    	calcScreen.setText(null);
    }

    @FXML
    void onFiftyButton(ActionEvent event) {
    	calcScreen.setText("50");
    }

    @FXML
    void onFiveButton(ActionEvent event) {

    }

    @FXML
    void onHundredButton(ActionEvent event) {

    }

    @FXML
    void onMenuArabicClick(ActionEvent event) {

    }

    @FXML
    void onMenuRomancClick(ActionEvent event) {

    }

    @FXML
    void onOneButton(ActionEvent event) {

    }

    @FXML
    void onTenButton(ActionEvent event) {

    }

}
